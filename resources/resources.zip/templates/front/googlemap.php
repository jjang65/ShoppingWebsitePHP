<script>
  var map;
  function initMap() {
    map = new google.maps.Map(document.getElementById('map'), {
      center: {lat: 49.8773953, lng: -97.2064861},
      zoom: 10
    });
  }
</script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDYjxOnHV8B_aVhv4WhKf4GN8W1dC40v8c&callback=initMap"
async defer></script>