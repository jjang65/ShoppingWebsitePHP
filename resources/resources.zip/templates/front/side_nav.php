<div class="col-md-2">
	<p class="lead">Categories</p>

	<!-- get_categories function -->
	<!-- <div class="list-group">
	    <a href="#" class="list-group-item">Category 1</a>
	    <a href="#" class="list-group-item">Category 2</a>
	    <a href="#" class="list-group-item">Category 3</a>
	</div> -->
	<?php get_categories(); ?>
</div>