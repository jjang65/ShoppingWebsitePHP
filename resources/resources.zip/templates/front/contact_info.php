<div class="row d-flex mt-5 contact-info">
     <div class="w-100"></div>
     <div class="col-md-3 d-flex">
     	<div class="info bg-white p-4">
            <p><span>Address:</span> Winnipeg, MB, Canada</p>
          </div>
     </div>
     <div class="col-md-3 d-flex">
     	<div class="info bg-white p-4">
            <p><span>Phone:</span> <a href="tel://204000000">+1 204 000 0000</a></p>
          </div>
     </div>
     <div class="col-md-3 d-flex">
     	<div class="info bg-white p-4">
            <p><span>Email:</span> <a href="mailto:jjy2@zzbai2.com">jjy2zzbai2@gmail.com</a></p>
          </div>
     </div>
     <div class="col-md-3 d-flex">
     	<div class="info bg-white p-4">
            <p><span>Website</span> <a href="http://jinyoungjang.net">jinyoungjang.com</a></p>
          </div>
     </div>
</div>