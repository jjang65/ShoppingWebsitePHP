
<section class="ftco-section bg-light">
	<div class="container">
			<div class="row justify-content-center mb-3 pb-3">
      <div class="col-md-12 heading-section text-center ftco-animate">
      	<h1 class="big">Products</h1>
        <h2 class="mb-4">Our Products</h2>
      </div>
    </div>    		
	</div>

	<div class="container-fluid">
		
			<div class="row">

				<div class="row col-md-12">

				<!-- Shopt Section Each Item -->
				<?php echo get_products_in_index(); ?>

				</div>
			
			</div>
	</div>
</section>