$(document).ready(function(){

$('#demo').hover(
  function () {
    $(this).toggle();

 
});



});