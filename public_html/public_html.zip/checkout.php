<?php require_once("../resources/config.php"); ?>

<?php require_once("resources/cart_functions.php"); ?>

<script src="js/formValidate.js" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="css/mysytles.css">

<!-- Header Section -->
<?php include(TEMPLATE_FRONT . DS . "header.php"); ?>
		
	<div class="hero-wrap hero-bread" style="background-image: url('images/bg_6.jpg');">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-0 bread">Checkout</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.php">Home</a></span> <span>Checkout</span></p>
          </div>
        </div>
      </div>
    </div>
		
	<section class="ftco-section">
	  <form id="orderform" action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post">
	  <input type="hidden" name="cmd" value="_cart">
  	  <input type="hidden" name="business" value="sb-f7ygs09627@business.example.com">
	  <input type="hidden" name="currency_code" value="CAD">
      <div class="container">
      	<div class="row">
    			<div class="col-md-12 ftco-animate">

    				<div class="cart-list">
	    				<table class="table">
	    					
						    <thead class="thead-primary">
						      <tr class="text-center">
						        <th>Image</th>
						        <th>Product</th>
						        <th>Price</th>
						        <th>Quantity</th>
						        <th>Total</th>
						      </tr>
						    </thead>
						    <tbody>

						      <?php checkout(); ?>
						      
						    </tbody>
						  </table>
					  </div>
    			</div>
    		</div>
        <div class="row justify-content-center">
          <div class="col-xl-8 ftco-animate">
	          <div class="row mt-5 pt-3 d-flex">
	          	<div class="col-md-6 d-flex">
	          		<div class="cart-detail cart-total bg-light p-3 p-md-4">
	          			<h3 class="billing-heading mb-4">Cart Total</h3>
	          			<p class="d-flex">
		    						<span>Subtotal</span>
		    						<span>
		    							<?php 
		    							echo isset($_SESSION['item_quantity']) ? $_SESSION['item_quantity'] : $_SESSION['item_quantity'] = "0";
		    							 ?>
		    						</span>
		    					</p>
		    					<p class="d-flex">
		    						<span>Delivery</span>
		    						<span>Free Shipping</span>
		    					</p>
		    					<!-- <p class="d-flex">
		    						<span>Discount</span>
		    						<span>$3.00</span>
		    					</p> -->
		    					<hr>
		    					<p class="d-flex total-price">
		    						<span>Total</span>
		    						<span>&#36;
		    							<?php 
		    							echo isset($_SESSION['item_total']) ? $_SESSION['item_total'] : $_SESSION['item_total'] = "0";
		    							 ?>
		    						</span>
		    					</p>
								</div>
	          	</div>
	          	<div class="col-md-6">
	          		<div class="cart-detail bg-light p-3 p-md-4">
	          			<h3 class="billing-heading mb-4">Payment Method</h3>
	          			
						<!-- <div class="form-group">
							<div class="col-md-12">
								<div class="radio">
								   <label><input type="radio" name="optradio" class="mr-2"> Direct Bank Tranfer</label>
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class="col-md-12">
								<div class="radio">
								   <label><input type="radio" name="optradio" class="mr-2"> Check Payment</label>
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class="col-md-12">
								<div class="radio">
								   <label><input type="radio" name="optradio" class="mr-2"> Paypal</label>
								</div>
							</div>
						</div> -->
						<!-- <div class="form-group">
							<div class="col-md-12">
								<div class="checkbox">
								   <label><input type="checkbox" value="" class="mr-2"> I have read and accept the terms and conditions</label>
								</div>
							</div>
						</div> -->
						<!-- <p><a href="#"class="btn btn-primary py-3 px-4">Place an order</a></p> -->
						<?php echo show_paypal(); ?>
					</div>
	          	</div>
	          </div>
          </div> <!-- .col-md-8 -->
        </div>
      </div>
      </form>
    </section> <!-- .section -->

    
<!-- Footer Section -->	
<?php include(TEMPLATE_FRONT . DS . "footer.php"); ?>